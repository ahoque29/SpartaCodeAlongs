﻿
//namespace CSharpSQLApp
//{
//    public class NorthwindContext : DbContext
//    {
//        public NorthwindContext()
//        {
//        }

//        public NorthwindContext(DbContextOptions<NorthwindContext> options)
//            : base(options)
//        { }
//        public virtual DbSet<Customer> Customers { get; set; }

//        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//        {
//            if (!optionsBuilder.IsConfigured)
//            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
//                optionsBuilder.UseSqlServer(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Northwind;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False;");
//            }
//        }

//        protected override void OnModelCreating(ModelBuilder modelBuilder)
//        {
//            modelBuilder.Entity<Customer>(entity =>
//            {
//                entity.HasKey(e => e.CustomerId);

//                entity.HasIndex(e => e.City)
//                    .HasName("City");

//                entity.HasIndex(e => e.CompanyName)
//                    .HasName("CompanyName");

//                entity.HasIndex(e => e.PostalCode)
//                    .HasName("PostalCode");

//                entity.HasIndex(e => e.Region)
//                    .HasName("Region");

//                entity.Property(e => e.CustomerId)
//                    .HasColumnName("CustomerID")
//                    .HasMaxLength(5)
//                    .IsFixedLength();

//                entity.Property(e => e.Address).HasMaxLength(60);

//                entity.Property(e => e.City).HasMaxLength(15);

//                entity.Property(e => e.CompanyName)
//                    .IsRequired()
//                    .HasMaxLength(40);

//                entity.Property(e => e.ContactName).HasMaxLength(30);

//                entity.Property(e => e.ContactTitle).HasMaxLength(30);

//                entity.Property(e => e.Country).HasMaxLength(15);

//                entity.Property(e => e.Fax).HasMaxLength(24);

//                entity.Property(e => e.Phone).HasMaxLength(24);

//                entity.Property(e => e.PostalCode).HasMaxLength(10);

//                entity.Property(e => e.Region).HasMaxLength(15);
//            });
//        }
//    }
//}

